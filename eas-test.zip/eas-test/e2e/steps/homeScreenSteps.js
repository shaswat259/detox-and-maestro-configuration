const { Given, When, Then } = require('@cucumber/cucumber');
const { expect } = require('detox');

Given('the app is launched', async () => {
  await device.launchApp();
});

When('I tap the {string} button', async (buttonId) => {
  await element(by.id(buttonId)).tap();
});

Then('the welcome message should be visible', async () => {
  await expect(element(by.text('Welcome!'))).toBeVisible();
});

Then('I should see the {string} message', async (message) => {
  await expect(element(by.text(message))).toBeVisible();
});
