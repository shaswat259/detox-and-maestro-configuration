describe('Home screen', () => {
  beforeAll(async () => {
    await device.launchApp();
  });

  beforeEach(async () => {
    await device.reloadReactNative();
  });

  it('welcome should be visible', async () => {
    await expect(element(by.text('Welcome!'))).toBeVisible();
  });

  // it('shows "Hi!" after tapping "Click me"', async () => {
  //   await element(by.id('click-me-button')).tap();
  //   await expect(element(by.text('Hi!'))).toBeVisible();
  // });
});
